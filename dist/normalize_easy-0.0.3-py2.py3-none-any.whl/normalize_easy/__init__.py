from .normalize_easy import normr, normc, normv
