## normalize_easy Package

This package implements normc() and normr() functions to easily normalize columns and rows respectively. 
This package uses `sklearn.preprocessing.normalize` and forced the input array to have dtype as float. The input array has to be 2-D.

### Future Work
* Implement doctests








